package usta.sistemas;

import java.sql.SQLOutput;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	/*AUTHOR: Juan David Neira Martinez
	 *DATE:30/03/2020
	 *DESCRIPTION: this software simulate a calculator
	 */
	Scanner keyboard=new Scanner(System.in);
	int sum, subtraction, multiplication, N1, N2, exit;
	double division;
	System.out.println("╔=======================================╗");
	System.out.println("║------------Menu (calculator)----------║");
	System.out.println("║   Select an option                    ║");
	System.out.println("║  1. Sum                               ║");
	System.out.println("║  2. Subtraction                       ║");
	System.out.println("║  3. Multiplication                    ║");
	System.out.println("║  4. Division                          ║");
	System.out.println("║  0. Exit                              ║");
	System.out.println("╚=======================================╝");


	System.out.println("this software simulate a calculator, input the first number");
	N1= keyboard.nextInt();
	System.out.println("input the second number");
	N2= keyboard.nextInt();
	sum= N1 + N2;
	System.out.println("the sumatory is:"+ sum);
	subtraction= N1 - N2;
	System.out.println("the subtraction is:"+ subtraction);
	multiplication= N1 * N2;
	System.out.println("the multiplication is:"+ multiplication);
	division= N1/N2;
	System.out.println("the division is:"+ division);
    }
}
