package usta.sistemas;

import javax.swing.*;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	/*AUTHOR: Juan David Neira Martinez
	 *DATE: 30/03/2020
	 *DESCRIPTION: this software serves to ask for your full name
	 */
	Scanner keyboard=new Scanner(System.in);
	String name;
	System.out.println("╔====================================╗");
	System.out.println("║         StringSft USTA 2020        ║");
	System.out.println("║             Versión 1.0            ║");
	System.out.println("║create by: Juan David Neira Martinez║");
	System.out.println("╚====================================╝");
	System.out.println("this program serves to ask for your full name, input your name");
	name=keyboard.nextLine();
	if (name.length()<6){
		System.out.println("ERROR: the name is very short, please enter your name");
	}else {
		if (name.length() > 20) {
			System.out.println("ERROR: the name is soo long, enter your full name");
		} else {
			System.out.println("your name is:" + name);
			System.out.println(name.replace("a", "@"));
			System.out.println("your name is:" + name);
			System.out.println(name.replace("e", "3"));
			System.out.println("your name is:" + name);
			System.out.println(name.replace("i", "1"));
			System.out.println("your name is:" + name);
			System.out.println(name.replace("o", "0"));
		}
	}
	}
}

