package usta.sistemas;

public class Main {

    public static void main(String[] args) {
	/*AUTHOR: Juan David Neira Martinez
	  DATE: 10/03/2020
	  DESCRIPTION: this software shows/prints HELLO WORLD
	 */
        System.out.println("hello world my name is Juan David Neira Martinez");
    }
}
