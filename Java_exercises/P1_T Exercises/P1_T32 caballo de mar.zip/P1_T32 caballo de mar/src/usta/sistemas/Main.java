package usta.sistemas;

public class Main {

    public static void main(String[] args) {
        /*AUTHOR: Juan David Neira Martinez
         DATE: 2020/03/10
         DESCRIPTION: this software shows a relief
         */
	System.out.println("________$$$$..");
	System.out.println("______$$$$$$$$$");
	System.out.println("______$$$$$$$_$");
	System.out.println("_____$$$$$$$$$$");
	System.out.println("______$$$$$$$$$$");
	System.out.println("_____$$$$$$_$$$$$");
	System.out.println("____$$$$$$$_____$$$");
	System.out.println("____$$$$$$$$_____$");
	System.out.println("____$$$$$$$$$$");
	System.out.println("_____$$$$$$$$$$");
	System.out.println("_____$$$$$$$$$$$");
	System.out.println("______$$$$$$$$$$$");
	System.out.println("_$$$$___$$$$$$$$$");
	System.out.println("__$$$$$$$$$$$$$$$");
	System.out.println("_$$$$$$$$$$$$$$$");
	System.out.println("__$$$$$$$$$$$$$");
	System.out.println("$$$$$$$$$$$$$");
	System.out.println("__$__$$$$$$");
	System.out.println("____$$$$$$");
	System.out.println("____$$$$$");
	System.out.println("___$$$$$$_____$");
	System.out.println("___$$$$$$___$$_$$");
	System.out.println("____$$$$$___$__$$");
	System.out.println("____$$$$$______$$");
	System.out.println("_____$$$$$____$$$");
	System.out.println("_______$$$$$$$$$");
	System.out.println("__________$$$$");

    }
}
