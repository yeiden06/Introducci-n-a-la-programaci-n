package usta.sistemas;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	/*AUTHOR: Juan David Neira Martinez
	 *DATE: 2020/03/12
	 *DESCRIPTION: this software input two variable and adds
	 */
	Scanner keyboard = new Scanner(System.in);
	int v1, v2, suma;
	System.out.println("this program adds two variables, input the first variable");
	v1=keyboard.nextInt();
	System.out.println("input the second variable");
	v2=keyboard.nextInt();
	suma= v1+v2;
	System.out.println("the sumatory is:"+ suma);
    }
}
