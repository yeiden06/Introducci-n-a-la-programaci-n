package usta.sistemas;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	/*AUTHOR:Juan David Neira Martinez
	 *DATE: 2020/03/12
	 *DESCRIPTION: this software declares three variables entire with different value assignment and adds and average them
	 */
	Scanner keyboard= new Scanner(System.in);
	int v1, v2, v3, suma;
	double average;
	System.out.println("this program input three variables, input the first variable");
	v1=keyboard.nextInt();
	System.out.println("input the second variable");
    v2=keyboard.nextInt();
    System.out.println("input the third variable");
    v3=keyboard.nextInt();
    suma=v1+v2+v3;
    average=suma/3;
    System.out.println("the sumatory is:"+suma+"the average is:"+average);



    }
}
