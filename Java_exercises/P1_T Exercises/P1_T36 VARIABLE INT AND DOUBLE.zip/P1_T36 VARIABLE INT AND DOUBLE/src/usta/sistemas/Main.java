package usta.sistemas;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	/*AUTHOR: Juan David Neira Martinez
	 *DATE: 2020/03/12
	 *DESCRIPTION: this software declare two variables X, Y and two variables N, M and assign each one a value, then show in the screen
	 */
	Scanner keyboard=new Scanner(System.in);
	int X, Y;
	double N, M;
	System.out.println("this software shows variables X, Y, N, M, input the number of X");
	X=keyboard.nextInt();
	System.out.println("input the number of Y");
    Y=keyboard.nextInt();
    System.out.println("input the number of N");
    N=keyboard.nextDouble();
    System.out.println("input the number of M");
    M=keyboard.nextDouble();
    System.out.println("the variables int are:"+X+" and "+Y);
    System.out.println("the variables double are:"+N+" and "+M);


    }
}
