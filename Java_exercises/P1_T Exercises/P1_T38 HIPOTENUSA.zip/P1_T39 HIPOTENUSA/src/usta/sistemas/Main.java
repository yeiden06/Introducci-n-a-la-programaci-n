package usta.sistemas;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	/*AUTHOR: Juan David Neira Martinez
	 *DATE: 2020/03/19
	 * DESCRIPTION: this software calculate the hipotenusa of a triangle
	 */
	Scanner keyboard= new Scanner(System.in);
	System.out.println("this program calculate the hipotenusa of a triangle, input the first leg (mts)");
	double leg1, leg2, hipotenusa;
	leg1=keyboard.nextDouble();
	System.out.println("input the second leg (mts)");
	leg2=keyboard.nextDouble();
	hipotenusa= Math.sqrt(Math.pow(leg1,2)+Math.pow(leg2,2));
	System.out.println("this hipotenusa is:"+hipotenusa);

    }
}
