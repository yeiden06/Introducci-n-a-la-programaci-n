package usta.sistemas;

import java.sql.SQLOutput;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	/*AUTHOR: Juan David Neira Martinez
	 *DATE: 26/03/2020
	 *DESCRIPTION: this software realizes many operations with strings
	 */
	Scanner keyboard= new Scanner(System.in);
	String name;
	System.out.println("-----------------------------------");
	System.out.println("                STRINGSOFT");
	System.out.println("-----------------------------------");
	System.out.println("input your name please: ");
	name= keyboard.nextLine();
	if (name.indexOf("gomez")!= -1){
		System.out.println("gomez already exists");
	}else{
		System.out.println("gomez doesn´t exists");
	}
	System.out.println("the upper name is "+name.toUpperCase());
	System.out.println(name.replace("a", "@"));
	System.out.println(name.substring(7));
    }
}
