package usta.sistemas;

import java.util.Scanner;

public class Main {


    public static void main(String[] args) {
	/*AUTHOR: Juan David Neira Martinez
	 *DATE: 25/03/2020
	 *DESCRIPTION: this program helps peopla to determinate if they have COVID-19
	 */
	Scanner keyboard=new Scanner(System.in);
	int cough, body_ache, difficulty_breathing, age;
	double degrees;
	System.out.println("----------------------------------------------------------------");
	System.out.println("                          Dr.coranovirus");
	System.out.println("----------------------------------------------------------------");
	System.out.println("this software determinates if you have coronavirus(COVID-19)");
	System.out.println("----------------------------------------------------------------");
	System.out.println("created by: Juan David Neira Martinez");
	System.out.println("----------------------------------------------------------------");

	System.out.println("input your age");
	age= keyboard.nextInt();
	System.out.println("next you were asked about the different symptoms of COVID-19, please answer with 1 for YES and 0 for NO, do you have a dry cough?");
    cough= keyboard.nextInt();
    System.out.println("do you have body pain? YES(1) NO(0): ");
    body_ache= keyboard.nextInt();
    System.out.println("do you have trouble breathing YES(1) NO(0): ");
    difficulty_breathing= keyboard.nextInt();
    System.out.println("what is your temperature? in degrees: ");
    degrees= keyboard.nextDouble();
    if (cough < 0 ]] cough > 1 ]] body_ache < 0 ]] body_ache > 1 ]] difficulty_breathing < 0 ]] difficulty_breathing > 1){
        System.out.println("ERROR: the answer must be 0 or 1");
        }else{ //si el usuario ingreso los datos correctos.

            if (cough == 1 && body_ache == 1 && difficulty_breathing == 1 && degrees > 38) {
                System.out.println("you have the symptoms of COVID-19");
                if (age >= 60) {
                    System.out.println("URGENT: do you need to go to hospital or your EPS");
                } else {
                    System.out.println("RELAX: you need to be in isolation at home");
                }else{//si no tiene los sintomas
                    System.out.println("you don´t have any symptoms, stay home");

                }
            }
            System.out.println("system crated by: Juan David Neira Martinez, please stay in home, take care");
        }
    }
}